To describe my experience and high-level approach to this assignment would be to say that I had to do a lot
of research about TCP clients and protocols because I was very confused about how it communicates with servers.
From the start of the program, I remember that TCP and UDP clients were talked about in class and also there
was an example of what TCP client looks in python3 so that was very useful for me start off with. From there
on, it was a matter of understanding how to express the different messages that were listed in the server
in my TCP client program. The most challenging part of this assignment was trying to communicate with one of the six
identical servers and also trying to understand how the math expression was important in this assignment.
I had to ask a lot of help from other tutors and students to assist me with this assignment. At the very end, I tested
the code by trying to go through which server port was available for me to communicate to and I watched the amount of 
code being displayed in the python3 terminal until the secret flag for my NUID was displayed.
